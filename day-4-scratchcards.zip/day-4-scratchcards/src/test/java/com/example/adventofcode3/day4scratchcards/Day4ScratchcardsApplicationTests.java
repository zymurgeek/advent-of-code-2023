package com.example.adventofcode3.day4scratchcards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4ScratchcardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
