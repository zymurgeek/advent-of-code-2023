package com.example.adventofcode3.day4scratchcards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4ScratchcardsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day4ScratchcardsApplication.class, args);
	}

}
